# terraform-module-repo-template
A repo template for terraform modules

The repo name should follow naming convention:

        terraform-<PROVIDER>-dnb_<servicename>

e.g.
        terraform-google-dnb_gcp_cloud_storage

And provide a short description of the purpose here. The module will need to be submitted to the DevX Platform team for peer-review via a pull-request, and then they can add it to our dnb-core TFC module registry.


## Quick Start

Test module locally:
```
make test
```

Apply configuration to currently configured/authenticated AWS ENV:
```
make test-apply
```

## Module Documentation
[Terraform docs](https://github.com/terraform-docs/terraform-docs) is used to ensure proper module documentation.

## Contributing


<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.0 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | >= 2.7 |

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_todo_my_variable"></a> [todo\_my\_variable](#input\_todo\_my\_variable) | n/a | `string` | `"some_value"` | no |
| <a name="input_todo_my_variable2"></a> [todo\_my\_variable2](#input\_todo\_my\_variable2) | n/a | `string` | `"todo"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_todo_my_output"></a> [todo\_my\_output](#output\_todo\_my\_output) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->