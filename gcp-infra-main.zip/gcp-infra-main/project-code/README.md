Executing this module and Pre-Requisites for GCP Services to Consume

`Serviceslist`

* GCS
* VPC/Subnet
* Cloud Router 
* Cloud Nat
* KMS
* GKE
    * Private
    * Public
    * Addon added
    * Autoscaling
* Enabling the api's on project


`Pre-Requisites`

* Make sure backend.tf is updated with right bucket and bucket should be created.
* Make sure you update the variables file with all the details.

`Sequence of steps to execute`

1. Make sure enabling apis module is executed

Commands to execute 
```
cd project-code/enable-apis/

terraform init
terraform plan
terraform apply -auto-approve
```

2. Run the project specific code vpc

Commands to execute 
```
cd project-code/vpc

terraform init
terraform plan
terraform apply -auto-approve
```

3. Run the project specific code kms

```
cd project-code/kms

terraform init
terraform plan
terraform apply -auto-approve
```

4. Run the project specific code gcs

```
cd project-code/gcs

terraform init
terraform plan
terraform apply -auto-approve
```

5. Run the project specific code crouter

```
cd project-code/crouter

terraform init
terraform plan
terraform apply -auto-approve
```

6. Run the project specific code gke

```
cd project-code/gke

terraform init
terraform plan
terraform apply -auto-approve
```