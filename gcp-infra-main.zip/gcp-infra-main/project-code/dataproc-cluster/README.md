Executing this module and Pre-Requisites for GCP Services to Consume

Serviceslist

Google cloud storage
dataproc-cluster

Make sure backend.tf is updated with right bucket and bucket should be created.
Make sure you update the variables file with all the details.
Sequence of steps to execute


cd project-code/dataproc-cluster

terraform init
terraform plan
terraform apply

Steps to follow after creating dataproc:


1.)Run the following commands in your Cloud Shell to clone the repo with the sample code and cd into the correct directory:

cd
git clone https://github.com/GoogleCloudPlatform/cloud-dataproc
cd ~/cloud-dataproc/codelabs/spark-bigquery

2.) Execute pySpark Job with dataproc:

gcloud dataproc jobs submit pyspark --cluster cluster-01 \
    --jars gs://spark-lib/bigquery/spark-bigquery-latest_2.12.jar \
    --driver-log-levels root=FATAL \
    counts_by_subreddit.py

3.) Running your backfill job:

cd ~/cloud-dataproc/codelabs/spark-bigquery
bash backfill.sh ${CLUSTER_NAME} ${BUCKET_NAME}
bash backfill.sh cluster-01 dataproc-output-cluster-01

4.) Confirm if jobs loaded into bucket:
gsutil ls gs://${BUCKET_NAME}/reddit_posts/*/*/food.csv.gz
