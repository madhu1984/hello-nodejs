Executing this module and Pre-Requisites for GCP Services to Consume

Serviceslist

Google cloud storage
cloud function
Cloud Composer

Make sure backend.tf is updated with right bucket and bucket should be created.
Make sure you update the variables file with all the details.
Sequence of steps to execute


cd project-code/cloud-composer

terraform init
terraform plan
terraform apply
Run the project specific code crouter


Steps to follow after creating composer:


1.) gcloud iam service-accounts add-iam-policy-binding \
valiant-guild-349519@appspot.gserviceaccount.com \
--member=serviceAccount:valiant-guild-349519@appspot.gserviceaccount.com \
--role=roles/iam.serviceAccountTokenCreator


2.) python3 get_client_id.py valiant-guild-349519 us-central1 uscentral1-composer-001

-> clientid - 119742494743-ajneh0cg2qpkd0nsjsi7o0k2r3v9jmk8.apps.googleusercontent.com


3.) git clone https://github.com/GoogleCloudPlatform/nodejs-docs-samples.git

4.)gcloud composer environments describe uscentral1-composer-001 --location us-central1:

config:
  airflowUri: https://w96e44d297d55d679p-tp.appspot.com
  dagGcsPrefix: gs://us-central1-uscentral1-comp-3fa37cca-bucket/dags
  databaseConfig:
    machineType: db-n1-standard-2
  encryptionConfig: {}
  gkeCluster: projects/valiant-guild-349519/zones/us-central1-f/clusters/us-central1-uscentral1-comp-3fa37cca-gke
  maintenanceWindow:
    endTime: '1970-01-01T04:00:00Z'
    recurrence: FREQ=WEEKLY;BYDAY=FR,SA,SU
    startTime: '1970-01-01T00:00:00Z'
  nodeConfig:
    diskSizeGb: 100
    ipAllocationPolicy: {}
    location: projects/valiant-guild-349519/zones/us-central1-f
    machineType: projects/valiant-guild-349519/zones/us-central1-f/machineTypes/n1-standard-8
    network: projects/valiant-guild-349519/global/networks/default
    oauthScopes:
    - https://www.googleapis.com/auth/cloud-platform
    serviceAccount: 403071294077-compute@developer.gserviceaccount.com
    subnetwork: projects/valiant-guild-349519/regions/us-central1/subnetworks/default
  nodeCount: 3
  privateEnvironmentConfig:
    cloudSqlIpv4CidrBlock: 10.0.0.0/12
    privateClusterConfig: {}
    webServerIpv4CidrBlock: 172.31.245.0/24
  softwareConfig:
    imageVersion: composer-1.18.11-airflow-1.10.15
    pythonVersion: '3'
    schedulerCount: 1
  webServerConfig:
    machineType: composer-n1-webserver-2
  webServerNetworkAccessControl:
    allowedIpRanges:
    - description: Allows access from all IPv4 addresses (default value)
      value: 0.0.0.0/0
    - description: Allows access from all IPv6 addresses (default value)
      value: ::0/0
  workloadsConfig: {}
createTime: '2022-06-09T09:22:43.208661Z'
name: projects/valiant-guild-349519/locations/us-central1/environments/uscentral1-composer-001
state: RUNNING
updateTime: '2022-06-09T09:39:45.690608Z'
uuid: d00effd8-8bcf-417b-8933-b5509f3aa328


5.) Ran nodejs sample code in cloud function after changing following details:

  // The project that holds your function
  const PROJECT_ID = 'valiant-guild-349519';
  // Navigate to your webserver's login page and get this from the URL
  const CLIENT_ID = '119742494743-ajneh0cg2qpkd0nsjsi7o0k2r3v9jmk8.apps.googleusercontent.com';
  // This should be part of your webserver's URL:
  // {tenant-project-id}.appspot.com
  const WEBSERVER_ID = 'w96e44d297d55d679p-tp'; 
  // The name of the DAG you wish to trigger
  const DAG_NAME = 'composer_sample_trigger_response_dag';

6.) Upload DAG to composer:

gcloud composer environments storage dags import \
    --environment uscentral1-composer-001 \
    --location us-central1 \
    --source trigger_response_dag.py

7.) Follow step 6 in workflow