
cloud_ids_name=$1
network_name=$2
cloud_ids_zone=$3
cloud_ids_severity=$4
subnets=$5
packet_mirroring_name=$1"-packet-mirroring"
region=$6
IFS=','
read -ra subnet_list <<< "$5"

gcloud ids endpoints create $cloud_ids_name \
--network=$network_name \
--zone=$cloud_ids_zone \
--severity=$cloud_ids_severity \
--async

x=0
st="READY"
while [ $x -eq 0 ]
do
  status=$(gcloud ids endpoints describe $cloud_ids_name --zone=$cloud_ids_zone --format="value(state)")
  #status=$(jq '.state' inprogress.json)
  echo $status
  if [[ $status == *"$st"* ]]; 
  then
  export FORWARDING_RULE=$(gcloud ids endpoints describe $cloud_ids_name --zone=$cloud_ids_zone --format="value(endpointForwardingRule)")
  echo $FORWARDING_RULE
  gcloud compute packet-mirrorings create $packet_mirroring_name \
  --region=us-east1 \
  --collector-ilb=$FORWARDING_RULE \
  --network=$network_name \
  --mirrored-subnets=cloud-ids-useast1
  x=1
  echo "cloud ids endpoint created."
  else
  echo "waiting...."
  sleep 180
  fi
done

