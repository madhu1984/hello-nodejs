import requests
import Settings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
def createWave(name, isWaveUpdate, payload):
  headers = {
  'Authorization': 'Basic {0}'.format(Settings.BASCIC_AUTH_TOKEN),
  'Content-Type': 'application/json'
  }
  url="{0}waves/{1}?update={2}".format(Settings.VELOSTRATA_API,name,isWaveUpdate) if isWaveUpdate==True else "{0}waves/{1}".format(Settings.VELOSTRATA_API,name)
  try:
    response = requests.request("PUT", url , headers=headers, data=payload, verify=False)
    return response
  except Exception as e:
    print(e)
    print("An error occured while creating wave")
    return ""
  