import requests
import Settings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
def validateRunbook(name):
  headers = {
  'Authorization': 'Basic {0}'.format(Settings.BASCIC_AUTH_TOKEN),
  'Content-Type': 'application/json'
  }
  
  try:
    response = requests.request("POST", "{0}waves/{1}/validations".format(Settings.VELOSTRATA_API,name), headers=headers,verify=False)
    return response
  except Exception as e:
    print("An error occured while validating wave")
    return ""

def getValidationStatus(waveName):
  headers = {
  'Authorization': 'Basic {0}'.format(Settings.BASCIC_AUTH_TOKEN),
  'Content-Type': 'application/json'
  }
  
  try:
    response = requests.request("GET", "{0}waves/{1}/validations".format(Settings.VELOSTRATA_API,waveName), headers=headers,verify=False)
    return response
  except Exception as e:
    print(e)
    print("An error occured while getting the validation wave")
    return ""