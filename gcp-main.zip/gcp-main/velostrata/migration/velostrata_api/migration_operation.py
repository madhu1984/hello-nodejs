import requests
import Settings
def migration_operation_job(wave_name,mig_operation_type):
  headers = {
  'Authorization': 'Basic {0}'.format(Settings.BASCIC_AUTH_TOKEN),
  'Content-Type': 'application/json'
  }
  
  try:
    response = requests.request("POST", "{0}waves/{1}?type={2}".format(Settings.VELOSTRATA_API,wave_name,mig_operation_type), headers=headers,verify=False)
    return response
  except:
    print("An error occured while creating migration job")
    return ""
  