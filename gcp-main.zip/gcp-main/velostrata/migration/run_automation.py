import json
from velostrata_api import create_wave,migration_operation,validate_runbook
def run_automation():
  f = open('migrationConfig.json',)
 
  # returns JSON object as
  config = json.load(f)
  for c in config:
    if c["applyChanges"] == True:
      print(c["waveName"])
      run_book_name=c["runbookName"]
      text = open("Runbooks\\{0}.csv".format(c["runbookName"]),"r")
    
      # joining with space content of text
      text = ' '.join([i for i in text])  
      #displaying result
      waveName=c["waveName"]
      updateRunbook=c["updateRunbook"]
      migrateOperation=c["migrateOperation"]
      ## Create migration wave
      response=create_wave.createWave(waveName,updateRunbook,text)
      if response.status_code==201:
        ## Run the validation on runbook
        valResponse=validate_runbook.validateRunbook(waveName)
        if valResponse.status_code == 202:
          ## Get the validation status
          validation_wave_response=validate_runbook.getValidationStatus(waveName)
          json_array=json.loads(validation_wave_response.text)
          validation_array_length=len(json_array)
          if validation_array_length == 0:
            ## Run migration job
            mig_response=migration_operation.migration_operation_job(waveName,migrateOperation)
            if mig_response.status_code == 201:
              print(mig_response.text)
            else:
              message="Errors:Unable to create migration job for Wave Name: {0} Runbook Name: {1} Error object: {2}".format(waveName, run_book_name, mig_response.text)
              print(message)
          else:
            ## display message
            message="Errors: Wave Name: {0} Runbook Name: {1} Eorror List: {2}".format(waveName,run_book_name,",".join(json_array))
            print(message)
        else:
          message="Failed to run the validation on Runbook: {0} wave name: {1}".format(run_book_name, waveName)
          print(message)
      else:
        message="Unable to create wave, wave name: {0} runbook: {1}".format(waveName,run_book_name)
        print(message)
             
            