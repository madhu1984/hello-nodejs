VELOSTRATA_API="https://35.184.197.236/auto/rest/"
BASCIC_AUTH_TOKEN="YXBpdXNlcjpsc3lqa3phMm1rbzY="