
import json 
import sys
import run_automation 
def main():
  run_automation.run_automation()

if __name__ == '__main__':
    sys.exit(main()) 



