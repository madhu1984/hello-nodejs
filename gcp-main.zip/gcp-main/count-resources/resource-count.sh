#!/bin/bash
# Script to retrieve GCP IAM roles, users and serviceaccounts
# Author - Basavaraj Biradar
echo 'project-name,resource-type,count' > /home/kumarbiradar7/resource_count.csv
resourceTypelistVar=("compute" "sql" "cnat" "lb")
prjs=($(gcloud projects list --filter="$(gcloud config get-value project)" --format="value(PROJECT_ID)"))
for i in "${prjs[@]}"
        do
                for r in "${resourceTypelistVar[@]}"
                        do
                                 case $r in
                                  compute)
                                        count=$(gcloud compute instances --project=$i list --format=json | jq '. | length')
                                        echo "$i,$r,$count">>/home/kumarbiradar7/resource_count.csv
                                        ;;
                                  sql)
                                        echo $r
                                        count=$(gcloud sql instances --project=$i list --format=json | jq '. | length')
                                        echo "$i,$r,$count">>/home/kumarbiradar7/resource_count.csv
                                        ;;
                                  lb)
                                        echo $r
                                        count=$(gcloud compute url-maps list --project=$i --format=json | jq '. | length')
                                        echo "$i,$r,$count">>/home/kumarbiradar7/resource_count.csv
                                        ;;
                                  *)
                                        echo "NONE"
                                        ;;
                                 esac

                        done
        done
